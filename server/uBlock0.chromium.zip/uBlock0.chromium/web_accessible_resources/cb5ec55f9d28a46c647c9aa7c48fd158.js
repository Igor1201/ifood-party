(function() {
	window.eval = function(s) {
		;
	}.bind(window);
})();
